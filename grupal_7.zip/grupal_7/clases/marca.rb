class Marca < Producto
    def alta_marca
    end
  
    def buscar_marca
    end
  
  
end