class Categoria < Producto
    def alta_categoria
end