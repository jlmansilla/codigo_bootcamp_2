#module Clases
  class Producto
    def generar_clave
    end

    def precio_final
    end

    def buscar_producto
    end

    def alta_producto
    end
  end
  
 def mostrar
 end

#end